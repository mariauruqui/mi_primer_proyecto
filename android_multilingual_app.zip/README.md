# Android Multilingual App

Este proyecto es una aplicación Android con soporte para múltiples idiomas y adaptación a diferentes tamaños de pantalla.

## Características
- Idiomas: Español, Inglés, Francés, Alemán
- Soporte para múltiples tamaños y orientaciones de pantalla
- Uso de imagen de fondo con archivo nine-patch

## Instalación
1. Clonar el repositorio en GitHub
2. Abrir en Android Studio
3. Ejecutar en un emulador o dispositivo físico
